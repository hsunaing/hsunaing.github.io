from uiautomator2 import Device

d = Device() 
d.app_start("com.myapp.app")  
d(text="Ok").click()  
text_data = d(text="TargetText").get_text()
print(text_data)
