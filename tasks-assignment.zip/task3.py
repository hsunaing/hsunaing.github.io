import requests
from itertools import cycle

proxies = ['http://proxy1', 'http://proxy2', 'http://proxy3']
proxy_pool = cycle(proxies)

for i in range(30): 
    proxy = next(proxy_pool)
    response = requests.get('https://api.apiurl.com', proxies={"http": proxy, "https": proxy})
    print(response.status_code)
