from androguard.core.bytecodes.apk import APK

class APKAnalyzer:
    def __init__(self, apk_file):
        self.apk = APK(apk_file)

    def get_metadata(self):
        return {
            'package': self.apk.get_package(),
            'version': self.apk.get_androidversion_name(),
            'permissions': self.apk.get_permissions(),
        }

analyzer = APKAnalyzer('path/to/app.apk')
print(analyzer.get_metadata())
