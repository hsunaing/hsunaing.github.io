from appium import webdriver

desired_caps = {
    "platformName": "Android",
    "deviceName": "emulator",
    "appPackage": "com.myapp.app",
    "appActivity": ".MainActivity"
}
driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)

driver.find_element_by_id('com.myapp.app:id/login').click()
driver.find_element_by_id('com.myapp.app:id/username').send_keys('testuser')
driver.find_element_by_id('com.myapp.app:id/password').send_keys('password')
driver.find_element_by_id('com.myapp.app:id/submit').click()

# Additional steps for different resolutions/orientations
driver.quit()
