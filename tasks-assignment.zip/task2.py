from celery import Celery
import requests
from sqlalchemy import create_engine

app = Celery('tasks', broker='redis://localhost:6379/0')

@app.task(bind=True, max_retries=3)
def fetch_and_store_data(self):
    try:
        response = requests.get('https://api.myapi.com/data')
        response.raise_for_status()
        data = response.json()


        engine = create_engine('sqlite:///mydatabase.db')
    
    
    except requests.exceptions.RequestException as exc:
        raise self.retry(exc=exc)